from typing import Any, Dict, List, Optional

import pandas as pd

from datetime import date


class DatabaseManagerExportsMixin:
    def _prorate_salary_for_hire_month(
        self,
        year: int,
        month: int,
        fecha_alta: Any,
        salario_mes: float,
    ) -> float:
        try:
            if not fecha_alta:
                return float(salario_mes or 0)

            if isinstance(fecha_alta, str):
                try:
                    fecha_alta_date = date.fromisoformat(fecha_alta[:10])
                except Exception:
                    return float(salario_mes or 0)
            elif isinstance(fecha_alta, date):
                fecha_alta_date = fecha_alta
            else:
                return float(salario_mes or 0)

            target_year = int(year)
            target_month = int(month)
            hire_year = int(fecha_alta_date.year)
            hire_month = int(fecha_alta_date.month)

            if (target_year, target_month) < (hire_year, hire_month):
                return 0.0

            if (target_year, target_month) != (hire_year, hire_month):
                return float(salario_mes or 0)

            day = int(fecha_alta_date.day)
            employed_days = max(0, 30 - (day - 1))
            return (float(salario_mes or 0) / 30.0) * float(employed_days)
        except Exception:
            return float(salario_mes or 0)

    def _calculate_salario_mes_for_export(
        self,
        month: int,
        payout_month: int,
        salario_mensual_bruto: float,
        atrasos: float,
        salario_mensual_bruto_prev: float,
        antiguedad: float,
        fte_porcentaje: float = 100.0,
    ) -> float:
        salario_mensual_bruto = float(salario_mensual_bruto or 0)
        atrasos = float(atrasos or 0)
        salario_mensual_bruto_prev = float(salario_mensual_bruto_prev or 0)
        antiguedad = float(antiguedad or 0)
        fte_porcentaje = float(fte_porcentaje or 100.0)

        months_before_payout = max(0, int(payout_month) - 1)
        fte_factor = fte_porcentaje / 100.0

        if months_before_payout > 0 and 1 <= int(month) <= months_before_payout:
            # Vorjahresgehalt, nur Basis mit FTE, antiguedad voll
            # Wenn Vorjahresgehalt 0 oder nicht vorhanden, verwendet aktuelles Gehalt
            prev_salary = float(salario_mensual_bruto_prev or 0)
            if prev_salary <= 0:
                # Kein Vorjahresgehalt - verwendet aktuelles Gehalt
                return (salario_mensual_bruto + antiguedad) * fte_factor
            else:
                return (prev_salary + antiguedad) * fte_factor
        elif int(month) == int(payout_month):
            # Neues Gehalt (reduzierte Basis) + monatsscharfe Atrasos + antiguedad
            base_salary = (salario_mensual_bruto + antiguedad) * fte_factor
            # Atrasos = Summe (new - old) * fte(k) für k=1..months_before_payout
            # Nur berechnen wenn Vorjahresgehalt > 0
            prev_salary = float(salario_mensual_bruto_prev or 0)
            if prev_salary > 0 and months_before_payout > 0:
                diff = salario_mensual_bruto - prev_salary
                atrasos_total = 0.0
                # Simulate month-specific FTE like frontend:
                # January: 100% (no FTE reduction yet)
                # February/March: current FTE (50%)
                for k in range(1, months_before_payout + 1):
                    if k == 1:  # January
                        month_fte = 1.0
                    else:  # February, March
                        month_fte = fte_factor
                    atrasos_total += diff * month_fte
                return base_salary + atrasos_total
            else:
                # Keine Atrasos wenn kein Vorjahresgehalt
                return base_salary
        else:
            # Normale Monate ab payoutMonth+1: neues Gehalt mit FTE, antiguedad voll
            return (salario_mensual_bruto + antiguedad) * fte_factor

    def export_nomina_excel(
        self,
        year: int,
        output_path: str,
        month: int = None,
        extra: bool = False,
    ) -> bool:
        """Exportiert Gehaltsdaten im Excel-Format - nur monatlicher Export wird unterstützt"""

        try:
            if not month:
                self.logger.error("Monatlicher Export erfordert eine Monatsangabe")
                return False

            extra_where = "AND s.modalidad = 14" if extra else ""

            query = f"""
            SELECT 
                e.id_empleado,
                CONCAT(e.apellido, ', ', e.nombre) as nombre_completo,
                e.ceco,
                e.fecha_alta,
                COALESCE(s.modalidad, 0) as modalidad,
                COALESCE(s.salario_mensual_bruto, 0) as salario_mensual_bruto,
                COALESCE(s.atrasos, 0) as atrasos,
                COALESCE(s.antiguedad, 0) as antiguedad,
                COALESCE(sp.salario_mensual_bruto, 0) as salario_mensual_bruto_prev,
                COALESCE((
                    SELECT f.porcentaje
                    FROM t008_empleado_fte f
                    WHERE f.id_empleado = e.id_empleado
                      AND (f.anio < %s OR (f.anio = %s AND f.mes <= %s))
                    ORDER BY f.anio DESC, f.mes DESC
                    LIMIT 1
                ), 100) as fte_porcentaje,
                COALESCE(i.ticket_restaurant, 0) as ticket_restaurant,
                COALESCE(d.cotizacion_especie, 0) as cotizacion_especie,
                COALESCE(i.primas, 0) as primas,
                COALESCE(i.lavado_coche, 0) as lavado_coche,
                COALESCE(i.beca_escolar, 0) as beca_escolar,
                COALESCE(i.dietas_cotizables, 0) as dietas_cotizables,
                COALESCE(i.horas_extras, 0) as horas_extras,
                COALESCE(i.seguro_pensiones, 0) as seguro_pensiones,
                COALESCE(d.seguro_accidentes, 0) as seguro_accidentes,
                COALESCE(i.dietas_exentas, 0) as dietas_exentas,
                COALESCE(i.formacion, 0) as formacion,
                COALESCE(d.adelas, 0) as adelas,
                COALESCE(d.sanitas, 0) as sanitas,
                COALESCE(d.gasolina, 0) as gasolina,
                COALESCE(i.dias_exentos, 0) as dias_exentos
            FROM t001_empleados e
            LEFT JOIN t002_salarios s ON e.id_empleado = s.id_empleado AND s.anio = %s
            LEFT JOIN t002_salarios sp ON e.id_empleado = sp.id_empleado AND sp.anio = %s
            LEFT JOIN t003_ingresos_brutos_mensuales i ON e.id_empleado = i.id_empleado AND i.anio = %s AND i.mes = %s
            LEFT JOIN t004_deducciones_mensuales d ON e.id_empleado = d.id_empleado AND d.anio = %s AND d.mes = %s
            WHERE e.activo = TRUE
            {extra_where}
            ORDER BY e.apellido, e.nombre
            """

            data = self.execute_query(query, (year, year, month, year, year - 1, year, month, year, month))

            if not data:
                self.logger.warning(f"Keine Daten für Jahr {year} gefunden")
                return False

            df = pd.DataFrame(data)

            # Convert all numeric columns to float to avoid decimal/float type issues
            numeric_columns = [
                'salario_mensual_bruto', 'atrasos', 'antiguedad', 'salario_mensual_bruto_prev',
                'fte_porcentaje',
                'ticket_restaurant', 'cotizacion_especie', 'primas', 'lavado_coche', 'beca_escolar', 'dietas_cotizables',
                'horas_extras', 'seguro_pensiones', 'seguro_accidentes', 'dietas_exentas',
                'formacion', 'adelas', 'sanitas', 'gasolina', 'dias_exentos'
            ]
            
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(float)

            # Apply carry over values (apply month = selected export month)
            try:
                employee_ids = [int(x) for x in df.get('id_empleado', pd.Series([])).fillna(0).astype(int).tolist() if int(x) > 0]
                carry_rows = self.get_carry_over_sums_for_apply(year, month, employee_ids) if employee_ids else []
                carry_map: Dict[int, Dict[str, float]] = {}
                for r in carry_rows or []:
                    try:
                        emp_id = int(r.get('id_empleado'))
                    except Exception:
                        continue
                    concept = str(r.get('concept', '')).strip().lower()
                    try:
                        amt = float(r.get('amount') or 0)
                    except Exception:
                        amt = 0.0
                    if emp_id not in carry_map:
                        carry_map[emp_id] = {}
                    carry_map[emp_id][concept] = carry_map[emp_id].get(concept, 0.0) + amt

                df['carry_salary'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('salary', 0.0)))
                df['carry_primas'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('primas', 0.0)))
                df['carry_horas_extras'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('horas_extras', 0.0)))
                df['carry_dietas_cotizables'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('dietas_cotizables', 0.0)))
                df['carry_dietas_exentas'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('dietas_exentas', 0.0)))
                df['carry_anticipos'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('anticipos', 0.0)))
                df['carry_cotizacion_especie'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('cotizacion_especie', 0.0)))
            except Exception as e:
                self.logger.error(f"Error applying carry over values: {str(e)}")
                df['carry_salary'] = 0.0
                df['carry_primas'] = 0.0
                df['carry_horas_extras'] = 0.0
                df['carry_dietas_cotizables'] = 0.0
                df['carry_dietas_exentas'] = 0.0
                df['carry_anticipos'] = 0.0
                df['carry_cotizacion_especie'] = 0.0

            payout_month = self.get_payout_month() if hasattr(self, "get_payout_month") else 4
            df['salario_mes'] = df.apply(
                lambda r: self._calculate_salario_mes_for_export(
                    month=month,
                    payout_month=payout_month,
                    salario_mensual_bruto=r.get('salario_mensual_bruto', 0),
                    atrasos=r.get('atrasos', 0),
                    salario_mensual_bruto_prev=r.get('salario_mensual_bruto_prev', 0),
                    antiguedad=r.get('antiguedad', 0),
                    fte_porcentaje=r.get('fte_porcentaje', 100),
                ),
                axis=1,
            )

            df['salario_mes'] = df.apply(
                lambda r: self._prorate_salary_for_hire_month(
                    year=year,
                    month=month,
                    fecha_alta=r.get('fecha_alta'),
                    salario_mes=r.get('salario_mes', 0),
                ),
                axis=1,
            )

            # Carry Over application
            df['salario_mes'] = df['salario_mes'] + df.get('carry_salary', 0)
            df['primas'] = df['primas'] + df.get('carry_primas', 0)
            df['horas_extras'] = df['horas_extras'] + df.get('carry_horas_extras', 0)
            df['dietas_cotizables'] = df['dietas_cotizables'] + df.get('carry_dietas_cotizables', 0)
            df['dietas_exentas'] = df['dietas_exentas'] + df.get('carry_dietas_exentas', 0)
            df['cotizacion_especie'] = df['cotizacion_especie'] + df.get('carry_cotizacion_especie', 0)

            # beca_escolar wird immer im Monat, in dem es eingetragen ist, zu Primas addiert
            df['primas'] = df['primas'] + df.get('beca_escolar', 0)
            if int(month) == 1:
                df['primas'] = df['primas'] + df.get('lavado_coche', 0)

            if extra:
                columns = [
                    'nombre_completo',
                    'ceco',
                    'salario_mes',
                ]
                df = df[columns]

                with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                    empty_df = pd.DataFrame([[None] * 3] * 3)
                    empty_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False)

                    header_row = pd.DataFrame([[None] * 3])
                    header_row.iloc[0, 0] = 'Suma de IMPORTE'
                    header_row.iloc[0, 1] = 'Etiquetas de columna'
                    header_row.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=3)

                    column_names = [
                        'Etiquetas de fila',
                        'CECO',
                        'SALARIO MES',
                    ]
                    columns_df = pd.DataFrame([column_names])
                    columns_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=4)

                    df.columns = column_names
                    df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=5)

                    empty_row_df = pd.DataFrame([[None] * len(column_names)])
                    empty_row_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=len(df) + 6)

                    last_row = len(df) + 7
                    worksheet = writer.sheets['Sheet1']

                    data_start_row = 6
                    data_end_row = len(df) + 5
                    worksheet[f'C{last_row}'] = f"=SUM(C{data_start_row}:C{data_end_row})"
                    worksheet[f'C{last_row}'].number_format = '#,##0.00'

                self.logger.info(f"Excel-Export erfolgreich: {output_path}")
                return True

            df['total'] = (
                df['salario_mes']
                + df['ticket_restaurant']
                + df['cotizacion_especie']
                + df['primas']
                + df['dietas_cotizables']
                + df['horas_extras']
                + df['seguro_pensiones']
                + df['seguro_accidentes']
                + df['dietas_exentas']
            )

            df['anticipos'] = df['ticket_restaurant'] + df['dietas_cotizables'] + df['dietas_exentas'] + df.get('carry_anticipos', 0)

            df['total_especie'] = df['cotizacion_especie'] + df['seguro_pensiones'] + df['seguro_accidentes']

            df['base_imponible'] = df['salario_mes'] + df['primas'] + df['horas_extras']

            df['seguro_medico'] = df['adelas'] + df['sanitas']

            columns = [
                'nombre_completo',          # A = Mitarbeiter
                'ceco',                     # B = CECO
                'salario_mes',              # C = SALARIO MES
                'ticket_restaurant',        # D = TICKET RESTAURANT
                'cotizacion_especie',       # E = COTIZACION ESPECIE
                'primas',                   # F = PRIMAS
                'dietas_cotizables',        # G = DIETAS COTIZABLES
                'horas_extras',             # H = HORAS EXTRAS
                'seguro_pensiones',         # I = SEGURO PENSIONES
                'seguro_accidentes',        # J = SEGURO ACCIDENTES
                'dietas_exentas',           # K = DIETAS EXENTAS
                'total',                    # L = TOTAL
                'formacion',                # M = FORMACION
                'adelas',                   # N = ADESLAS
                'sanitas',                  # O = SANITAS
                'gasolina',                 # P = GASOLINA
                'anticipos',                # Q = ANTICIPOS
                'total_especie',            # R = TOTAL ESPECIE
                'dias_exentos',             # S = DIAS EXENTOS
                'base_imponible',           # T = BASE IMPONIBLE
                'dietas_cotizables',        # U = DIETAS COTIZABLES (Kopie von G)
                'dietas_exentas',           # V = DIETAS EXENTAS (Kopie von K)
                'ticket_restaurant',        # W = TICKETS (Kopie von D)
                'total_especie',            # X = RET. ESPECIE (Kopie von R)
                'seguro_medico',            # Y = SEGURO MEDICO
            ]

            df = df[columns]

            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                empty_df = pd.DataFrame([[None] * 25] * 3)
                empty_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False)

                header_row = pd.DataFrame([[None] * 25])
                header_row.iloc[0, 0] = 'Suma de IMPORTE'
                header_row.iloc[0, 1] = 'Etiquetas de columna'
                header_row.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=3)

                column_names = [
                    'Etiquetas de fila',          # A
                    'CECO',                       # B
                    'SALARIO MES',                # C
                    'TICKET RESTAURANT',          # D
                    'COTIZACIÓN ESPECIE',         # E
                    'PRIMAS',                     # F
                    'DIETAS COTIZABLES',          # G
                    'HORAS EXTRAS',               # H
                    'SEGURO PENSIONES',           # I
                    'SEGURO ACCIDENTES',          # J
                    'DIETAS EXENTAS',             # K
                    'TOTAL',                      # L
                    'FORMACION',                  # M
                    'ADESLAS',                    # N
                    'SANITAS',                    # O
                    'GASOLINA',                   # P
                    'ANTICIPOS',                  # Q
                    'TOTAL ESPECIE',              # R
                    'DÍAS EXENTOS',               # S
                    'BASE IMPONIBLE',             # T
                    'DIETAS COTIZABLES',          # U (Kopie)
                    'DIETAS EXENTAS',             # V (Kopie)
                    'TICKETS',                    # W (Kopie)
                    'RET. ESPECIE',               # X (Kopie)
                    'SEGURO MÉDICO',              # Y
                ]

                columns_df = pd.DataFrame([column_names])
                columns_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=4)

                df.columns = column_names
                df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=5)

                empty_row_df = pd.DataFrame([[None] * len(column_names)])
                empty_row_df.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=len(df) + 6)

                last_row = len(df) + 7
                worksheet = writer.sheets['Sheet1']

                for col_idx in range(2, 26):
                    col_letter = chr(65 + col_idx)
                    if col_letter <= 'Z':
                        if col_idx - 1 < len(column_names):
                            col_name = column_names[col_idx - 1]
                            if col_name not in ['Etiquetas de fila', 'CECO']:
                                data_start_row = 6
                                data_end_row = len(df) + 5
                                formula = f"=SUM({col_letter}{data_start_row}:{col_letter}{data_end_row})"
                                worksheet[f'{col_letter}{last_row}'] = formula
                                cell = worksheet[f'{col_letter}{last_row}']
                                cell.number_format = '#,##0.00'

            self.logger.info(f"Excel-Export erfolgreich: {output_path}")
            return True

        except Exception as e:
            self.logger.error(f"Fehler beim Excel-Export: {e}")
            return False

    def export_asiento_nomina_excel(self, year: int, month: int, output_path: str) -> bool:
        """Exportiert Gehaltsdaten im Asiento Nomina Excel-Format"""

        try:
            query = """
            SELECT 
                e.id_empleado,
                e.ceco,
                CONCAT(e.apellido, ', ', e.nombre) as nombre_completo,
                e.fecha_alta,
                COALESCE(s.salario_mensual_bruto, 0) as salario_mensual_bruto,
                COALESCE(s.atrasos, 0) as atrasos,
                COALESCE(s.antiguedad, 0) as antiguedad,
                COALESCE(sp.salario_mensual_bruto, 0) as salario_mensual_bruto_prev,
                COALESCE((
                    SELECT f.porcentaje
                    FROM t008_empleado_fte f
                    WHERE f.id_empleado = e.id_empleado
                      AND (f.anio < %s OR (f.anio = %s AND f.mes <= %s))
                    ORDER BY f.anio DESC, f.mes DESC
                    LIMIT 1
                ), 100) as fte_porcentaje,
                COALESCE(i.ticket_restaurant, 0) as ticket_restaurant,
                COALESCE(d.cotizacion_especie, 0) as cotizacion_especie,
                COALESCE(i.primas, 0) as primas,
                COALESCE(i.dietas_cotizables, 0) as dietas_cotizables,
                COALESCE(i.horas_extras, 0) as horas_extras,
                COALESCE(i.seguro_pensiones, 0) as seguro_pensiones,
                COALESCE(d.seguro_accidentes, 0) as seguro_accidentes,
                COALESCE(i.dietas_exentas, 0) as dietas_exentas,
                COALESCE(i.formacion, 0) as formacion,
                COALESCE(d.adelas, 0) as adelas,
                COALESCE(d.sanitas, 0) as sanitas,
                COALESCE(d.gasolina, 0) as gasolina,
                COALESCE(i.dias_exentos, 0) as dias_exentos
            FROM t001_empleados e
            LEFT JOIN t002_salarios s ON e.id_empleado = s.id_empleado AND s.anio = %s
            LEFT JOIN t002_salarios sp ON e.id_empleado = sp.id_empleado AND sp.anio = %s
            LEFT JOIN t003_ingresos_brutos_mensuales i ON e.id_empleado = i.id_empleado AND i.anio = %s AND i.mes = %s
            LEFT JOIN t004_deducciones_mensuales d ON e.id_empleado = d.id_empleado AND d.anio = %s AND d.mes = %s
            WHERE e.activo = TRUE
            ORDER BY e.apellido, e.nombre
            """

            data = self.execute_query(query, (year, year, month, year, year - 1, year, month, year, month))

            if not data:
                self.logger.warning(f"Keine Daten für Jahr {year}, Monat {month} gefunden")
                return False

            df = pd.DataFrame(data)

            # Convert all numeric columns to float to avoid decimal/float type issues
            numeric_columns = [
                'salario_mensual_bruto', 'atrasos', 'antiguedad', 'salario_mensual_bruto_prev',
                'fte_porcentaje',
                'ticket_restaurant', 'cotizacion_especie', 'primas', 'dietas_cotizables',
                'horas_extras', 'seguro_pensiones', 'seguro_accidentes', 'dietas_exentas',
                'formacion', 'adelas', 'sanitas', 'gasolina', 'dias_exentos'
            ]
            
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(float)

            # Apply carry over values (apply month = selected export month)
            try:
                employee_ids = [int(x) for x in df.get('id_empleado', pd.Series([])).fillna(0).astype(int).tolist() if int(x) > 0]
                carry_rows = self.get_carry_over_sums_for_apply(year, month, employee_ids) if employee_ids else []
                carry_map: Dict[int, Dict[str, float]] = {}
                for r in carry_rows or []:
                    try:
                        emp_id = int(r.get('id_empleado'))
                    except Exception:
                        continue
                    concept = str(r.get('concept', '')).strip().lower()
                    try:
                        amt = float(r.get('amount') or 0)
                    except Exception:
                        amt = 0.0
                    if emp_id not in carry_map:
                        carry_map[emp_id] = {}
                    carry_map[emp_id][concept] = carry_map[emp_id].get(concept, 0.0) + amt

                df['carry_salary'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('salary', 0.0)))
                df['carry_primas'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('primas', 0.0)))
                df['carry_horas_extras'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('horas_extras', 0.0)))
                df['carry_dietas_cotizables'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('dietas_cotizables', 0.0)))
                df['carry_dietas_exentas'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('dietas_exentas', 0.0)))
                df['carry_cotizacion_especie'] = df['id_empleado'].apply(lambda eid: float(carry_map.get(int(eid), {}).get('cotizacion_especie', 0.0)))
            except Exception:
                df['carry_salary'] = 0.0
                df['carry_primas'] = 0.0
                df['carry_horas_extras'] = 0.0
                df['carry_dietas_cotizables'] = 0.0
                df['carry_dietas_exentas'] = 0.0
                df['carry_cotizacion_especie'] = 0.0

            payout_month = self.get_payout_month() if hasattr(self, "get_payout_month") else 4
            df['salario_mes'] = df.apply(
                lambda r: self._calculate_salario_mes_for_export(
                    month=month,
                    payout_month=payout_month,
                    salario_mensual_bruto=r.get('salario_mensual_bruto', 0),
                    atrasos=r.get('atrasos', 0),
                    salario_mensual_bruto_prev=r.get('salario_mensual_bruto_prev', 0),
                    antiguedad=r.get('antiguedad', 0),
                    fte_porcentaje=r.get('fte_porcentaje', 100),
                ),
                axis=1,
            )

            df['salario_mes'] = df.apply(
                lambda r: self._prorate_salary_for_hire_month(
                    year=year,
                    month=month,
                    fecha_alta=r.get('fecha_alta'),
                    salario_mes=r.get('salario_mes', 0),
                ),
                axis=1,
            )

            # Carry Over application
            df['salario_mes'] = df['salario_mes'] + df.get('carry_salary', 0)
            df['primas'] = df['primas'] + df.get('carry_primas', 0)
            df['horas_extras'] = df['horas_extras'] + df.get('carry_horas_extras', 0)
            df['dietas_cotizables'] = df['dietas_cotizables'] + df.get('carry_dietas_cotizables', 0)
            df['dietas_exentas'] = df['dietas_exentas'] + df.get('carry_dietas_exentas', 0)
            df['cotizacion_especie'] = df['cotizacion_especie'] + df.get('carry_cotizacion_especie', 0)

            df['seguro_medico'] = df['adelas'] + df['sanitas']
            df['combustible'] = df['gasolina']

            month_names = [
                '',
                'Enero',
                'Febrero',
                'Marzo',
                'Abril',
                'Mayo',
                'Junio',
                'Julio',
                'Agosto',
                'Septiembre',
                'Octubre',
                'Noviembre',
                'Diciembre',
            ]

            month_str = month_names[month]
            month_year_str = f"NOMINA {month}.{str(year)[2:]}"

            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                workbook = writer.book
                worksheet = workbook.create_sheet('Sheet1')

                column_widths = {
                    'A': 15,
                    'B': 3,
                    'C': 3,
                    'D': 15,
                    'E': 3,
                    'F': 3,
                    'G': 25,
                    'H': 3,
                    'I': 3,
                    'J': 3,
                    'K': 3,
                    'L': 10,
                    'M': 25,
                    'N': 30,
                }

                for col, width in column_widths.items():
                    worksheet.column_dimensions[col].width = width

                row_num = 1

                worksheet[f'A{row_num}'] = 'Cta.General'
                worksheet[f'B{row_num}'] = 'TEXTO BREVE'
                worksheet[f'D{row_num}'] = 'IMPORTE'
                worksheet[f'E{row_num}'] = 'IMPORTE EN MON.'
                worksheet[f'G{row_num}'] = 'TEXTO'
                worksheet[f'L{row_num}'] = 'CeCo'
                row_num += 1

                worksheet[f'A{row_num}'] = 142710300
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = month_year_str
                worksheet[f'M{row_num}'] = 'IRPF'
                row_num += 1

                worksheet[f'A{row_num}'] = 142921300
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = month_year_str
                worksheet[f'M{row_num}'] = 'SEG.SOC.'
                row_num += 1

                for idx, emp in df.iterrows():
                    worksheet[f'A{row_num}'] = 162111110
                    worksheet[f'C{row_num}'] = 'D'
                    worksheet[f'D{row_num}'] = emp['salario_mes']
                    worksheet[f'G{row_num}'] = month_year_str
                    worksheet[f'L{row_num}'] = emp['ceco']
                    if idx == 0:
                        worksheet[f'M{row_num}'] = 'SUELDOS Y SALARIOS'
                    worksheet[f'N{row_num}'] = emp['nombre_completo']
                    row_num += 1

                for idx, emp in df.iterrows():
                    worksheet[f'A{row_num}'] = 162711150
                    worksheet[f'C{row_num}'] = 'D'
                    worksheet[f'D{row_num}'] = ''
                    worksheet[f'G{row_num}'] = month_year_str
                    worksheet[f'L{row_num}'] = emp['ceco']
                    if idx == 0:
                        worksheet[f'M{row_num}'] = 'SEG.SOCIAL A CARGO EMPRESA'
                    worksheet[f'N{row_num}'] = emp['nombre_completo']
                    row_num += 1

                for idx, emp in df.iterrows():
                    worksheet[f'A{row_num}'] = 162511500
                    worksheet[f'C{row_num}'] = 'D'
                    worksheet[f'D{row_num}'] = emp['horas_extras'] if emp['horas_extras'] > 0 else ''
                    worksheet[f'G{row_num}'] = month_year_str
                    worksheet[f'L{row_num}'] = emp['ceco']
                    if idx == 0:
                        worksheet[f'M{row_num}'] = 'HORAS EXTRAS'
                    worksheet[f'N{row_num}'] = emp['nombre_completo']
                    row_num += 1

                for idx, emp in df.iterrows():
                    worksheet[f'A{row_num}'] = 162610500
                    worksheet[f'C{row_num}'] = 'D'
                    worksheet[f'D{row_num}'] = emp['primas'] if emp['primas'] > 0 else ''
                    worksheet[f'G{row_num}'] = month_year_str
                    worksheet[f'L{row_num}'] = emp['ceco']
                    if idx == 0:
                        worksheet[f'M{row_num}'] = 'PRIMAS'
                    worksheet[f'N{row_num}'] = emp['nombre_completo']
                    row_num += 1

                total_seguro_medico = df['seguro_medico'].sum()
                total_combustible = df['combustible'].sum()

                worksheet[f'A{row_num}'] = 642100004
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = f"{month_year_str} Seg. Medico"
                worksheet[f'D{row_num}'] = total_seguro_medico
                worksheet[f'M{row_num}'] = 'SANITAS+ADESLAS'
                row_num += 1

                worksheet[f'A{row_num}'] = 628100005
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = f"{month_year_str} COMBUSTIBLE"
                worksheet[f'D{row_num}'] = total_combustible
                worksheet[f'M{row_num}'] = 'COMBUSTIBLE'
                row_num += 1

                worksheet[f'A{row_num}'] = 476000003
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = month_year_str
                worksheet[f'M{row_num}'] = 'SEG. SOCIAL A PAGAR'
                row_num += 1

                worksheet[f'A{row_num}'] = 465000006
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = month_year_str
                worksheet[f'M{row_num}'] = 'LIQUIDO A PERCIBIR'
                row_num += 1

                worksheet[f'A{row_num}'] = 142951200
                worksheet[f'C{row_num}'] = 'H'
                worksheet[f'G{row_num}'] = month_year_str
                row_num += 1

                sum_row = row_num
                formula = f'=SUMIF(N:N,"*",D:D)-SUMIF(N:N,"",D:D)+D{sum_row}'
                worksheet[f'D{row_num}'] = formula

            self.logger.info(f"Asiento Nomina Excel-Export erfolgreich: {output_path}")
            return True

        except Exception as e:
            self.logger.error(f"Fehler beim Asiento Nomina Excel-Export: {e}")
            return False

    def export_irpf_excel(self, year: int, month: Optional[int], output_path: str, extra: bool = False) -> bool:

        try:
            if month is not None and (int(month) < 1 or int(month) > 12):
                return False

            month_names = [
                '',
                'ENERO',
                'FEBRERO',
                'MARZO',
                'ABRIL',
                'MAYO',
                'JUNIO',
                'JULIO',
                'AGOSTO',
                'SEPTIEMBRE',
                'OCTUBRE',
                'NOVIEMBRE',
                'DICIEMBRE',
            ]

            export_months: List[Dict[str, Any]] = []
            if month is None:
                for m in range(1, 13):
                    export_months.append({'mes': int(m), 'label': month_names[int(m)], 'extra': False})
                export_months.append({'mes': 6, 'label': 'EXTRA VERANO', 'extra': True})
                export_months.append({'mes': 12, 'label': 'EXTRA NAVIDAD', 'extra': True})
            else:
                m_i = int(month)
                if extra and m_i == 6:
                    export_months.append({'mes': 6, 'label': 'EXTRA VERANO', 'extra': True})
                elif extra and m_i == 12:
                    export_months.append({'mes': 12, 'label': 'EXTRA NAVIDAD', 'extra': True})
                else:
                    export_months.append({'mes': m_i, 'label': month_names[m_i], 'extra': False})

            payout_month = self.get_payout_month() if hasattr(self, "get_payout_month") else 4

            all_rows: List[Dict[str, Any]] = []

            for mdef in export_months:
                m = int(mdef['mes'])
                is_extra = bool(mdef.get('extra'))

                extra_where = "AND s.modalidad = 14" if is_extra else ""

                query = f"""
                SELECT
                    e.id_empleado,
                    CONCAT(e.apellido, ' ', e.nombre) as nombre_completo,
                    e.fecha_alta,
                    e.declaracion,
                    e.dni,
                    COALESCE(s.salario_mensual_bruto, 0) as salario_mensual_bruto,
                    COALESCE(s.atrasos, 0) as atrasos,
                    COALESCE(s.antiguedad, 0) as antiguedad,
                    COALESCE(sp.salario_mensual_bruto, 0) as salario_mensual_bruto_prev,
                    COALESCE((
                        SELECT f.porcentaje
                        FROM t008_empleado_fte f
                        WHERE f.id_empleado = e.id_empleado
                          AND (f.anio < %s OR (f.anio = %s AND f.mes <= %s))
                        ORDER BY f.anio DESC, f.mes DESC
                        LIMIT 1
                    ), 100) as fte_porcentaje,
                    COALESCE(i.ticket_restaurant, 0) as ticket_restaurant,
                    COALESCE(i.dietas_cotizables, 0) as dietas_cotizables,
                    COALESCE(i.dietas_exentas, 0) as dietas_exentas,
                    COALESCE(i.formacion, 0) as formacion,
                    COALESCE(d.cotizacion_especie, 0) as cotizacion_especie,
                    COALESCE(d.seguro_accidentes, 0) as seguro_accidentes,
                    COALESCE(i.seguro_pensiones, 0) as seguro_pensiones,
                    COALESCE(d.adelas, 0) as adelas,
                    COALESCE(d.sanitas, 0) as sanitas
                FROM t001_empleados e
                LEFT JOIN t002_salarios s ON e.id_empleado = s.id_empleado AND s.anio = %s
                LEFT JOIN t002_salarios sp ON e.id_empleado = sp.id_empleado AND sp.anio = %s
                LEFT JOIN t003_ingresos_brutos_mensuales i ON e.id_empleado = i.id_empleado AND i.anio = %s AND i.mes = %s
                LEFT JOIN t004_deducciones_mensuales d ON e.id_empleado = d.id_empleado AND d.anio = %s AND d.mes = %s
                WHERE e.activo = TRUE
                {extra_where}
                ORDER BY e.apellido, e.nombre
                """

                data = self.execute_query(query, (year, year, m, year, year - 1, year, m, year, m))
                if not data:
                    continue

                df = pd.DataFrame(data)

                numeric_columns = [
                    'salario_mensual_bruto', 'atrasos', 'antiguedad', 'salario_mensual_bruto_prev',
                    'fte_porcentaje',
                    'ticket_restaurant', 'dietas_cotizables', 'dietas_exentas', 'formacion',
                    'cotizacion_especie', 'seguro_accidentes', 'seguro_pensiones', 'adelas', 'sanitas'
                ]
                for col in numeric_columns:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(float)

                df['salario_mes'] = df.apply(
                    lambda r: self._calculate_salario_mes_for_export(
                        month=m,
                        payout_month=payout_month,
                        salario_mensual_bruto=r.get('salario_mensual_bruto', 0),
                        atrasos=r.get('atrasos', 0),
                        salario_mensual_bruto_prev=r.get('salario_mensual_bruto_prev', 0),
                        antiguedad=r.get('antiguedad', 0),
                        fte_porcentaje=r.get('fte_porcentaje', 100),
                    ),
                    axis=1,
                )
                df['salario_mes'] = df.apply(
                    lambda r: self._prorate_salary_for_hire_month(
                        year=year,
                        month=m,
                        fecha_alta=r.get('fecha_alta'),
                        salario_mes=r.get('salario_mes', 0),
                    ),
                    axis=1,
                )

                df['seguro_medico'] = df['adelas'] + df['sanitas']
                df['total_especie'] = df['cotizacion_especie'] + df['seguro_pensiones'] + df['seguro_accidentes']

                for _, r in df.iterrows():
                    decl = str(r.get('declaracion') or '').strip().upper() or None
                    dni = r.get('dni')
                    dni_out = dni if decl == 'EXTERNO' else None

                    sueldo = float(r.get('salario_mes') or 0)
                    dietas_cot = float(r.get('dietas_cotizables') or 0)
                    dietas_ex = float(r.get('dietas_exentas') or 0)
                    ticket = float(r.get('ticket_restaurant') or 0)
                    especie = float(r.get('total_especie') or 0)
                    seguro_medico = float(r.get('seguro_medico') or 0)
                    formacion = float(r.get('formacion') or 0)

                    perceptor_val = 0 if decl == 'EXTERNO' else 1
                    perceptor_especie_val = 0 if decl == 'EXTERNO' else 1

                    # For EXTRA months: I, J, N, Q must be 0
                    if mdef.get('label') in ('EXTRA VERANO', 'EXTRA NAVIDAD'):
                        ticket = 0
                        especie = 0
                        seguro_medico = 0
                        perceptor_especie_val = 0

                    all_rows.append(
                        {
                            'NOMBRE': r.get('nombre_completo'),
                            'DECLARACION': decl,
                            'MES': str(mdef.get('label') or ''),
                            'DNI': dni_out,
                            'sueldo cotiz.': sueldo,
                            'sueldo no cot.': None,
                            'dietas cot.': dietas_cot,
                            'dietas no cot.': dietas_ex,
                            'ticket': ticket,
                            'retrib.especie': especie,
                            'I.R.P.F.': None,
                            'RETENC.ESPECIE': None,
                            'SEG.SOC': None,
                            'SEGURO MEDICO': seguro_medico,
                            'FORMACION': formacion,
                            'PERCEPTOR': perceptor_val,
                            'PERCEPTOR ESPECIE': perceptor_especie_val,
                            'BASE IMPONIBLE': sueldo + dietas_cot + especie,
                            'NO SOMETIDAS A RETENCION': dietas_ex + ticket,
                        }
                    )

            if not all_rows:
                return False

            out_df = pd.DataFrame(all_rows)

            ordered_columns = [
                'NOMBRE',
                'DECLARACION',
                'MES',
                'DNI',
                'sueldo cotiz.',
                'sueldo no cot.',
                'dietas cot.',
                'dietas no cot.',
                'ticket',
                'retrib.especie',
                'I.R.P.F.',
                'RETENC.ESPECIE',
                'SEG.SOC',
                'SEGURO MEDICO',
                'FORMACION',
                'PERCEPTOR',
                'PERCEPTOR ESPECIE',
                'BASE IMPONIBLE',
                'NO SOMETIDAS A RETENCION',
            ]
            out_df = out_df[ordered_columns]

            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                out_df.to_excel(writer, sheet_name='RETENCIONES IRPF', index=False)

            return True

        except Exception as e:
            self.logger.error(f"Fehler beim IRPF Excel-Export: {e}")
            return False
